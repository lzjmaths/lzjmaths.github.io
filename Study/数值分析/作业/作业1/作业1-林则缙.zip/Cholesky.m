%Cholesky method
function X=Cholesky(A,b);
now=[A,b];
[row,col]=size(A);
for j=1:row
    L(j,j)=A(j,j);
    for k=1:j-1
        L(j,j)=L(j,j)-L(j,k)*L(j,k);
    end
    L(j,j)=L(j,j)^0.5;
    for i=j+1:col
        L(i,j)=A(i,j);
        for k=1:j-1
            L(i,j)=L(i,j)-L(i,k)*L(j,k);
        end
        L(i,j)=L(i,j)/L(j,j);
    end
end
x=Gauss(L,b);
X=Gauss(L',x);
end